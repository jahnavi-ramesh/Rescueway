package Automationproject.Rescueway;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

public class About extends BaseTest {
	@Test
	public void verifyTitleOfAboutPage()
	{
		driver.findElement(By.xpath("//a[text()='About']")).click();
		
		String actualTitle = driver.getTitle();
		Assert.assertTrue(actualTitle.contains("RescueWay"), "Title Mismatch");
	}
}
