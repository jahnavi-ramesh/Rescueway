package Automationproject.Rescueway;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;

public class BaseTest {
	public WebDriver driver;
	WebDriverWait wait;
	JavascriptExecutor js;

	
	@BeforeClass
	public void setup()
	{
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		js = (JavascriptExecutor) driver;
		wait = new WebDriverWait(driver,Duration.ofSeconds(10));
		driver.get("https://rescueway.pythonanywhere.com/");
	}
	
	@AfterClass
	public void tearDown()
	{
		if(driver!=null)
		{
			driver.quit();
		}
	}
	
	public void waitForPageToLoad(String url)
	{
		wait.until(ExpectedConditions.urlToBe(url));
	}
	
	@AfterMethod(alwaysRun = true)
	public void takeScreenshotAndTearDown(ITestResult result) {
		if (driver != null) {
			
				TakesScreenshot takeScreenshot = (TakesScreenshot) driver;
				File source = takeScreenshot.getScreenshotAs(OutputType.FILE);
				String testName = result.getName();
				String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
				File destination = new File(
						"C:\\Users\\Jahna\\eclipse-workspace\\Rescueway\\Screenshorts" + testName + timestamp + ".png");
				try {
					Files.copy(source.toPath(), destination.toPath());
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
	}
	
	public void scrollIntoElement(WebElement element) {
	    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block: 'center', inline: 'center'});", element);
	}
}
