package Automationproject.Rescueway;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Home extends BaseTest{
	@Test
	public void verifyTitleOfHomePage()
	{
		driver.findElement(By.xpath("//a[@class='nav-item nav-link active']")).click();
		
		String actualTitle = driver.getTitle();
		Assert.assertTrue(actualTitle.contains("RescueWay"), "Title Mismatch");
	}
}
