package Automationproject.Rescueway;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Login extends BaseTest{
	@Test
	public void verifyLoginWithValidCredentials() {
		
		driver.findElement(By.xpath("//a[text()='SignIn']")).click();
		driver.findElement(By.xpath("//input[@id='loginEmail']")).sendKeys("jahnavi3124@gmail.com");
		driver.findElement(By.xpath("//input[@id='loginPassword']")).sendKeys("admin123");
		WebElement loginButton = driver.findElement(By.xpath("//button[text()='Login']"));
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		wait.until(ExpectedConditions.elementToBeClickable(loginButton));
		scrollIntoElement(loginButton);
	    ((JavascriptExecutor) driver).executeScript("arguments[0].click();", loginButton);

		//loginButton.click();
		Assert.assertTrue(driver.getPageSource().contains("About"), "Login Failed");
	}
}
