package Automationproject.Rescueway;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Logout extends BaseTest{
	@Test
	public void verifyLogout() {
		driver.findElement(By.xpath("//a[text()='SignIn']")).click();
		driver.findElement(By.xpath("//input[@id='loginEmail']")).sendKeys("jahnavi3124@gmail.com");
		driver.findElement(By.xpath("//input[@id='loginPassword']")).sendKeys("admin123");
		driver.findElement(By.xpath("//button[text()='Login']")).click();
		driver.findElement(By.xpath("//a[@id='userDropdown']")).click();
		driver.findElement(By.xpath("//a[text()='Logout']")).click();
		waitForPageToLoad("https://rescueway.pythonanywhere.com/");
		Assert.assertTrue(driver.getCurrentUrl().equals("https://rescueway.pythonanywhere.com/"), "Logout Failed");	
		
	}
}
