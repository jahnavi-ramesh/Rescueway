package Automationproject.Rescueway;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Pages extends BaseTest {
	@Test
	public void verifyPagesLinkLoadsDropDown()
	{
		driver.findElement(By.xpath("//a[text()='Pages']")).click();
		WebElement dropDown = driver.findElement(By.xpath("//div[@class='dropdown-menu m-0 show']"));
		Assert.assertTrue(dropDown.isDisplayed(), "Pages Link didin't displayed dropdown");
	}
}
