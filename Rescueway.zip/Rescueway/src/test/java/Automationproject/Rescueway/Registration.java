package Automationproject.Rescueway;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Registration extends BaseTest {
	@Test
	public void verifyRegistrationWithValidDetails() {
		driver.findElement(By.xpath("//a[text()='SignUp']")).click();
		waitForPageToLoad("https://rescueway.pythonanywhere.com/signup/");
		driver.findElement(By.xpath("//input[@id='signUpName']")).sendKeys("Jahnavi");
		driver.findElement(By.xpath("//input[@id='signUpEmail']")).sendKeys("jahnaviuser123@gmail.com");
		driver.findElement(By.xpath("//input[@id='signUpPhone']")).sendKeys("6238986797");

		driver.findElement(By.xpath("//input[@id='signUpPassword']")).sendKeys("password@123");
		driver.findElement(By.xpath("//input[@id='signUpConfirmPassword']")).sendKeys("password@123");
		WebElement signupButton = driver.findElement(By.xpath("//button[text()='Sign Up']"));
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		wait.until(ExpectedConditions.elementToBeClickable(signupButton));
		scrollIntoElement(signupButton);
		
	    ((JavascriptExecutor) driver).executeScript("arguments[0].click();", signupButton);
		waitForPageToLoad("https://rescueway.pythonanywhere.com/login/");
		Assert.assertTrue(driver.getCurrentUrl().equals("https://rescueway.pythonanywhere.com/login/"),
				"registration Failed");
	}
}
